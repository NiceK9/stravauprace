/*!
 * FullScreen Search
 * 
 * 
 * @author 
 * @version 1.0
 * Copyright . 
 */
"use strict";

/**
 * jQuery.browser.mobile (http://detectmobilebrowser.com/)
 *
 * jQuery.browser.mobile will be true if the browser is a mobile device
 *
 **/
(function(a){(jQuery.browser=jQuery.browser||{}).mobile=/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4))})(navigator.userAgent||navigator.vendor||window.opera);
var fullscreensearchEngine = new function(){

    var me = this;

    this.animations = {
        "search": {
            "hide": "fadeOutUp",
            "show": "fullsearch-ig-min fadeInUp"
        }
    };

    this.show = {
        "class": "",
        "admin": function(){
            if(jQuery("#wpadminbar").length)
                jQuery("#wpadminbar").fadeIn();
        },
        "header": function(header){
            var el = fullscreensearch.header;
            jQuery(el).addClass("hidden");            
            jQuery(el).html(header);
            jQuery(el).removeClass("hidden");                        
        },
        "dest": function(){            
            //jQuery(fullscreensearch.dest).css({'display':'block'});            
            jQuery(fullscreensearch.header).fadeIn();
            jQuery(fullscreensearch.dest).fadeIn();
            jQuery(fullscreensearch.header).addClass("fullsearch-results");
        },
        "default": function(){
            jQuery(fullscreensearch.header).fadeIn();
            jQuery("[data-fullscreensearch-default]").css({'display':'block'});
        },
        "engine":  function(){                        
            me.hide.admin();
            
            if(!jQuery(fullscreensearch.container).hasClass(me.show.class)){
                jQuery("html").css({"overflow":"hidden"});
                jQuery(fullscreensearch.container).addClass(me.show.class);
                jQuery(fullscreensearch.container).css({
                    'display':'block'
                });
                fullscreensearch.dots();
                jQuery(fullscreensearch.screeninput).first().focus();
                jQuery(fullscreensearch.container).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
                    jQuery(fullscreensearch.container).removeClass(me.show.class);
                });
            }
        },
        "loader": function(){
            jQuery(fullscreensearch.loader).css({"display":"block"});
        }
    };

    this.hide = {
        "class":  "",
        "admin": function(){
            if(jQuery("#wpadminbar").length)
                jQuery("#wpadminbar").fadeOut();
        },
        "default" : function(){            
            //jQuery("[data-fullscreensearch-default]").css({'display':'none'});   
            //jQuery(fullscreensearch.header).fadeOut();
            if(jQuery("[data-fullscreensearch-default]").is(":visible")){
                jQuery("[data-fullscreensearch-default]").fadeOut();                                
                jQuery(fullscreensearch.header).html(jQuery(fullscreensearch.container).attr("data-fullscreensearch-loadingtext"));
            }
        },
        "dest": function(){
            //jQuery(fullscreensearch.header).fadeOut();
            //jQuery(fullscreensearch.dest).css({'display':'none'});
            jQuery(fullscreensearch.dest).fadeOut();
        },
        "header": function(){
            var el = fullscreensearch.header;
            var header = jQuery(el).attr("data-fullscreensearch-headerdefault");

            jQuery(el).addClass("hidden");
            jQuery(el).html(header);
            jQuery(el).removeClass("hidden");                        
        },
        "clear": function(){
            jQuery("[data-fullscreensearch-prev]").addClass("hidden");
            jQuery("[data-fullscreensearch-next]").addClass("hidden");            
            jQuery(fullscreensearch.header).html(jQuery(fullscreensearch.container).attr("data-fullscreensearch-loadingtext"));
            me.hide.dest();
        },
        "engine": function(){
            me.hide.dest();
            me.show.default();
            me.show.admin();

            jQuery("html").css({"overflow":fullscreensearch.overflow});
            jQuery(fullscreensearch.container).removeClass(me.show.class);
            jQuery(fullscreensearch.top).attr("class","");
            
            jQuery(fullscreensearch.responseEl).removeClass(fullscreensearch.responseClass);
            jQuery(fullscreensearch.container).addClass(me.hide.class);                        
            
            jQuery(fullscreensearch.container).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){                
                if(jQuery(fullscreensearch.container).hasClass(me.hide.class)){
                    jQuery(fullscreensearch.container).css({'display':'none'});
                    jQuery(fullscreensearch.container).removeClass(me.hide.class);
                }                
                
                if(jQuery(fullscreensearch.container).attr("data-fullscreensearch-defaultvalue")=="empty")
                    jQuery(".fullsearch-container").removeClass("no-flex");  
            });
            
            jQuery(fullscreensearch.input).val("");
            jQuery(fullscreensearch.screeninput).val("");
            
            
            jQuery(fullscreensearch.top).removeAttr("data-spy");
            
            me.hide.clear();
            me.hide.header();
        },
        "loader": function(){
            jQuery(fullscreensearch.loader).css({"display":"none"});
        },
        "center": function(){
            if(!jQuery(".fullsearch-container").hasClass("no-flex"))
                jQuery(".fullsearch-container").addClass("no-flex");
        },
        "multiple": function(){
            if(jQuery(fullscreensearch.dest).find(".row").length>1){
                jQuery(fullscreensearch.dest).find(".row").remove();
                jQuery(fullscreensearch.dest).html("<div class='row hidden'></div>");
            }
        }
    };

    this.search = {
        "init": 0,
        "transfer": function(callback){
            if(me.search.init == 0){
                me.search.init = 1;
                var el = jQuery("[data-fullscreensearch-search]");
                el.addClass(me.animations.search.hide);
                
                jQuery(fullscreensearch.top).attr("data-spy","affix");
                
                el.one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
                    jQuery(".fullsearch-container [data-fullscreensearch-search]").remove();
                    jQuery("[data-fullscreensearch-top]").addClass("activeTop");                    
                    jQuery("[data-fullscreensearch-top] button").before(el);
                    el.removeClass(me.animations.search.hide);

                    el.addClass(me.animations.search.show);
                    callback();
                });
            }else{
                callback();
            }
        },
        "restore": function(){
            var el = jQuery("[data-fullscreensearch-search]");
            el.removeClass(me.animations.search.show);
            jQuery("[data-fullscreensearch-top] [data-fullscreensearch-search]").remove();
            jQuery(".fullsearch-container [data-fullscreensearch-header]").before(el);            
            me.search.init = 0;
            jQuery(el).removeClass("fullsearch-results");                              
        }
    };   

    this.setAnimations = function(){
        var animation = jQuery(fullscreensearch.container).attr("data-fullscreensearch-animation");
        if(typeof animation == "undefined" || animation==""){
            me.show.class = "zoomInDown";
            me.hide.class = "zoomOutUp";
        }else{
            animation = animation.split("|");
            me.show.class = animation[0];
            me.hide.class = animation[1];
        }
    };

    this.searchRequest = function(){
        me.show.loader();                
        
        me.hide.default();
        
        me.search.transfer(function(){                                
        
            jQuery.post(fullscreensearchvariabls.ajaxurl, {
                action: 'fullsearchAjax',
                security: fullscreensearchvariabls.security,
                page: fullscreensearchPage,
                section: 'ajax',
                type: 'results',
                phrase: jQuery(fullscreensearch.screeninput).val()
            }, function (response) {
                    me.hide.loader();
                    me.show.dest();

                    if(response.page==1){                    
                        me.hide.center();
                        me.hide.multiple();
                        me.show.header(response.header);                                                                                
                    }                                

                    var method = "fullscreensearchResult" + fullscreensearch.resultkind;
                    window[method]["next"](response);


            },"json");
        
        });
    };

    this.callSearch = function(){
        if(jQuery(fullscreensearch.screeninput).val()!="")
        {
            fullscreensearchPage = 1;
            me.hide.clear();
            me.searchRequest();            
            
            me.fixed(100,"#fullsearch-header");
        }
    };

    this.exit = function(){
        jQuery(fullscreensearch.screeninput).first().blur();
    };
    
    this.fixed = function(height,el,classes){                
        jQuery("#fullsearch-view").scroll(function(){            
            if(jQuery("#fullsearch-view").scrollTop()>=height){                
                jQuery(el).removeClass("affix-top");
                jQuery(el).addClass("affix");
            }else{                
                jQuery(el).removeClass("affix");
                jQuery(el).addClass("affix-top");
            }
        });
    };
}

var fullscreensearchResultcommon = new function(){
    this.hasScroll = function(){
        return jQuery("#fullsearch-view")[0].scrollHeight > jQuery("#fullsearch-view").innerHeight();
    };
};

var fullscreensearchResultadd = new function(){
    var me = this;

    this.next = function(response){
        if(response.page==1){
            var el = jQuery(fullscreensearch.dest).find(".row");
            el.html(response.view);
            el.removeClass("hidden");
            el.addClass("animated fadeIn");
        }else{
            jQuery(fullscreensearch.dest).find(".row").append(response.view);
        }

        fullscreensearch.dots();

        if(parseInt(response.next,10)){            
            jQuery("[data-fullscreensearch-next]").removeClass("hidden");
        }else
            jQuery("[data-fullscreensearch-next]").addClass("hidden");

        fullscreensearchPage++;
    };

    this.bindEvents = function(){
        jQuery(fullscreensearch.container).on(fullscreensearch.event,"[data-fullscreensearch-next]",function(){
            jQuery("[data-fullscreensearch-next]").addClass("hidden");
            fullscreensearchEngine.searchRequest();
        });
    };
}

var fullscreensearchResultscroll = new function(){
    var me = this;

    this.scroll = true;   
    this.pending = false;
    this.lastLoaded = 0;

    this.next = function(response){
        if(response.page==1){
            var el = jQuery(fullscreensearch.dest).find(".row");
            el.html(response.view);
            el.removeClass("hidden");
            el.addClass("animated fadeIn");
            me.lastLoaded = 0;
        }else{
            jQuery(fullscreensearch.dest).find(".row").append(response.view);
        }      

        fullscreensearch.dots();

        me.scroll = parseInt(response.next,10);

        fullscreensearchPage++;
                       
        setTimeout(function(){            
            if(me.scroll && fullscreensearchResultcommon.hasScroll()==false){            
                me.lastLoaded = fullscreensearchPage-1;
                fullscreensearchEngine.searchRequest();
            }
        },1000);
    };        

    this.bindEvents = function(){                   
        jQuery(fullscreensearch.container).scroll(function() {                        
            if(jQuery(fullscreensearch.screeninput).val()!="" && jQuery(this).scrollTop() + jQuery(this).innerHeight()>=jQuery(this)[0].scrollHeight-10){                
                if(me.scroll && me.lastLoaded != fullscreensearchPage){                                        
                    me.lastLoaded = fullscreensearchPage;
                    fullscreensearchEngine.searchRequest();
                }
            }
        });
    };
}

var fullscreensearchResultslide = new function(){
    var me = this;

    me.fullLoaded = 0;
    me.lastLoaded = 0;
    me.current = 1;   
    me.width = 0;

    this.class = {
        "left": {
            show: "zoomIn",//"slideInDown",//"slideInLeft",//fadeIn
            hide: "zoomOut"//"slideOutDown"//"slideOutRight" //fadeOut
        },
        "right": {
            show: "zoomIn",//"slideInUp",//"slideInRight", //fadeIn
            hide: "zoomOut"//"slideOutUp"//"slideOutLeft" //fadeOut
        }
    };

    this.animations = {
      "set":function(){
            var data = jQuery(fullscreensearch.container).attr("data-fullscreensearch-slideanimation");        
            if(typeof data != "undefined" && data != ""){
                var split = data.split("|");
                me.class.left.show = split[0];
                me.class.left.hide = split[1];
                me.class.right.show = split[2];
                me.class.right.hide = split[3];
            }
      },
      "prev": {
          "slide": function(el){
                  me.animations.run(el,{
                    "before":{
                        "remove":"hidden",
                        "add": "animated "+me.class.left.show
                    },
                    "after":{
                        "remove":me.class.left.show,// + " hidden",
                        "add": ""
                    }
                });
          },
          "rest": function(prevEl,nextEl){
              me.animations.run(nextEl,{
                "before":{
                    "remove":"",
                    "add": "animated "+me.class.left.hide //hidden
                },
                "after":{
                    "remove":me.class.left.hide,
                    "add": "hidden"
                }
            },function(){
                me.animations.run(prevEl,{
                    "before":{
                        "remove":"hidden",
                        "add": "animated "+me.class.left.show
                    },
                    "after":{
                        "remove":me.class.left.show,// + " hidden",
                        "add": ""
                    }
                });
            });
          }
      },
      "next": {
          "slide": function(el){
                me.animations.run(el,{
                    "before":{
                        "remove":"",
                        "add": "animated "+me.class.right.show
                    },
                    "after":{
                        "remove":me.class.right.show,// + " hidden",
                        "add": ""
                    }
                });
          },
          "rest": function(prevEl,nextEl){
              me.animations.run(prevEl,{
                "before":{
                    "remove":"",
                    "add": "animated "+me.class.right.hide //hidden
                },
                "after":{
                    "remove":me.class.right.hide,
                    "add": "hidden"
                }
            },function(){
                me.animations.run(nextEl,{
                    "before":{
                        "remove":"hidden",
                        "add": "animated "+me.class.right.show
                    },
                    "after":{
                        "remove":me.class.right.show,// + " hidden",
                        "add": ""
                    }
                });
            });
          }
      },
      "run": function(el,classes,callback){

            el.removeClass(classes.before.remove);
            el.addClass(classes.before.add);

            el.one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
                    el.addClass(classes.after.add);
                    el.removeClass(classes.after.remove);

                    if(typeof callback!="undefined")
                        callback();
            });

        }
    };     
    
    this.checkIfSlide = function(){
        return me.class.left.show.indexOf("slide")==-1 ? false : true;
    }   

    this.prev = {
        "click": function(){
            if(fullscreensearchPage>1 && me.current>1){
                me.current--;
                me.prev.animate();
                me.checkButtons();
            }
        },
        "animate": function(){                        
            if(me.checkIfSlide()){
                var el = jQuery(fullscreensearch.dest);
                me.animations.prev.slide(el);
            }else{
                var prevEl = jQuery(fullscreensearch.dest).find(".row").eq(me.current-1);
                var nextEl = jQuery(fullscreensearch.dest).find(".row").eq(me.current);
                me.animations.prev.rest(prevEl,nextEl);
            }
        },
        "hide": function(){
            jQuery("[data-fullscreensearch-prev]").addClass("hidden");
        },
        "show": function(){
            jQuery("[data-fullscreensearch-prev]").removeClass("hidden");
        }
    };           

    this.next = function(response){
        if(fullscreensearchPage==1){
            me.fullLoaded = 0;
            me.lastLoaded = 1;
            me.current = 1;
            me.width = jQuery(fullscreensearch.dest).width();                    
        }       

        if(!me.fullLoaded && me.current == me.lastLoaded){
            if(typeof response != "undefined"){
                if(response.page==1){
                    var el = jQuery(fullscreensearch.dest).find(".row");
                    el.html(response.view);
                    
                    me.animations.run(el,{
                        "before":{
                            "remove":"hidden",
                            "add": "animated "+me.class.right.show
                        },
                        "after":{
                            "remove":me.class.right.show,
                            "add": ""
                        }
                    },function(){
                        
                    });                    
                    
                }else{
                    jQuery(fullscreensearch.dest).append("<div class='row hidden'>"+response.view+"</div>");                    
                    me.current++;
                    me.nextAdditional.animate();
                }

                me.bindSwipe(fullscreensearch.dest + " .row:last");
                fullscreensearch.dots();

                me.fullLoaded = parseInt(response.next,10) ? 0 : 1;

                if(!me.fullLoaded){
                    me.lastLoaded = fullscreensearchPage;
                    fullscreensearchPage++;
                }

                me.checkButtons();
                //jQuery("#fullsearch-view").css('overflow', 'visible');
            }else{
                fullscreensearchEngine.searchRequest();
            }
        }else if(me.current<=me.lastLoaded){
            me.current++;
            me.nextAdditional.animate();
            me.checkButtons();
        }
    };

    this.checkButtons = function(){
        if(me.current == 1){
            me.prev.hide();
        }else if(me.current > 1){
            me.prev.show();
        }

        if(me.current == fullscreensearchPage){
            me.nextAdditional.hide();
        }else if(me.current < fullscreensearchPage){
            me.nextAdditional.show();
        }
    };

    this.nextAdditional = {
        "animate": function(){                                    
            if(me.checkIfSlide()){
                var el = jQuery(fullscreensearch.dest);
                me.animations.next.slide(el);
            }else{
                var prevEl = jQuery(fullscreensearch.dest).find(".row").eq(me.current-2);
                var nextEl = jQuery(fullscreensearch.dest).find(".row").eq(me.current-1);
                me.animations.next.rest(prevEl,nextEl);
            }
        },
        "hide": function(){
            jQuery("[data-fullscreensearch-next]").addClass("hidden");
        },
        "show": function(){
            jQuery("[data-fullscreensearch-next]").removeClass("hidden");
        }
    };

    this.bindSwipe = function(el){        
        jQuery(el).swipe({            
            swipeLeft:function(event, direction, distance, duration, fingerCount, fingerData) {                
                if(jQuery("[data-fullscreensearch-next]").css("display")=="block"){
                    jQuery("[data-fullscreensearch-next]").trigger(fullscreensearch.event);
                }
            },
            swipeRight:function(event, direction, distance, duration, fingerCount, fingerData) {
                if(jQuery("[data-fullscreensearch-prev]").css("display")=="block"){
                    jQuery("[data-fullscreensearch-prev]").trigger(fullscreensearch.event);
                }
            }
        });
    };

    this.bindEvents = function(){    
        jQuery("#fullsearch-view").css('overflow-x', 'hidden');
        
        me.animations.set();

        jQuery(fullscreensearch.container).on(fullscreensearch.event,"[data-fullscreensearch-prev]",function(){
           me.prev.click();
        });

        jQuery(fullscreensearch.container).on(fullscreensearch.event,"[data-fullscreensearch-next]",function(){
            me.next();
        });

        me.bindSwipe(fullscreensearch.dest + " .row");
    };
}

var fullscreensearchPage = 1;

var fullscreensearch = new function(){

    var me = this;

    this.input = "#fullscreensearch_input";
    this.container = "[data-fullscreensearch-container]";
    this.screeninput = "[data-fullscreensearch-input]";
    this.dest = "[data-fullscreensearch-destinaiton]";
    this.header = "[data-fullscreensearch-header]";
    this.loader = "[data-fullscreensearch-loader]";
    this.top = "[data-fullscreensearch-top]";

    this.overflow = jQuery("html").css("overflow");

    this.idleTimeout = 5000;
    this.timeout = false;    

    this.event;

    this.init = function(){
        if(jQuery(me.input).length == 1 && jQuery(me.container).length == 0){
            jQuery.post(fullscreensearchvariabls.ajaxurl, {
                action: 'fullsearchAjax',
                security: fullscreensearchvariabls.security,
                page: me.page,
                section: 'ajax',
                type: 'container'
            }, function (response) {
                jQuery("body").append(response);

                fullscreensearchEngine.setAnimations();

                me.resultkind = jQuery(me.container).attr("data-fullscreensearch-result");

                me.dots();

                me.liveEvents();

                var method = "fullscreensearchResult"+me.resultkind;
                window[method]["bindEvents"]();
            });
        }
    };

    this.dots = function(){
        var args = {
            ellipsis: ' ...'
        };
        var el = me.container + " .fullsearch-single-box-inside ";
        jQuery(el+" .fullsearch-intro").dotdotdot(args);
        jQuery(el+" h3").dotdotdot(args);
    };

    this.liveEvents = function(){
        jQuery(me.container).on(me.event,"[data-fullscreensearch-close]",function(){
           fullscreensearchEngine.hide.engine();
           fullscreensearchEngine.search.restore();
        });

        jQuery(me.container).on("keyup",me.screeninput,function(e){
            if(e.keyCode == 13)
            {
                fullscreensearchEngine.exit();
                fullscreensearchEngine.callSearch();
            }else if(e.keyCode == 27)
            {
                fullscreensearchEngine.hide.engine();
                fullscreensearchEngine.search.restore();
            }
        });

        jQuery(me.container).on(me.event,".fullsearch-input-group .icon-search",function(){
            fullscreensearchEngine.exit();
            fullscreensearchEngine.callSearch();
        });
    };

    this.bindEvents = function(){
        me.event = jQuery.browser.mobile ? "touchstart" : "click";

        jQuery(me.input).on("focus",function(){
            fullscreensearchEngine.show.engine();
        });        

        jQuery(window).resize(function(){
           me.dots();
        });
    };

};

jQuery("document").ready(function(){
    fullscreensearch.init();
    fullscreensearch.bindEvents();    
});

jQuery("#fcsearchforminput").focus();